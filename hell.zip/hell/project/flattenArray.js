function flattenArray(arr) {
    return arr.flat(Infinity);
  }
  
  module.exports = flattenArray;
  