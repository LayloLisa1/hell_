function averageArray(arr) {
    return arr.reduce((acc, val) => acc + val, 0) / arr.length;
  }
  
  module.exports = averageArray;
  