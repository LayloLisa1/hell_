function findMin(arr) {
    return Math.min(...arr);
  }
  
  module.exports = findMin;
  