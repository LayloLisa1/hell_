function findMax(arr) {
    return Math.max(...arr);
  }
  
  module.exports = findMax;
  