function removeDuplicates(arr) {
    return [...new Set(arr)];
  }
  
  module.exports = removeDuplicates;
  