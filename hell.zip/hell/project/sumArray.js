function sumArray(arr) {
    return arr.reduce((acc, val) => acc + val, 0);
  }
  
  module.exports = sumArray;
  