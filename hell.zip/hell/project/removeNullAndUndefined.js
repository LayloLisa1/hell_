function removeNullAndUndefined(arr) {
    return arr.filter(val => val !== null && val !== undefined);
  }
  
  module.exports = removeNullAndUndefined;
  