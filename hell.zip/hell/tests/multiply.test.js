const multiply = require('../project/multiply');
const assert = require('assert');

describe('multiply', function() {
  it('should return 6 when multiplying 2 and 3', function() {
    assert.strictEqual(multiply(2, 3), 6);
  });

  it('should return -1 when multiplying -1 and 1', function() {
    assert.strictEqual(multiply(-1, 1), -1);
  });

  it('should return 0 when multiplying 0 and 5', function() {
    assert.strictEqual(multiply(0, 5), 0);
  });
});
