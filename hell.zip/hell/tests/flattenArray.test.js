const flattenArray = require('../project/flattenArray');
const assert = require('assert');

describe('flattenArray', function() {
  it('should return [1, 2, 3, 4, 5] for [1, [2, [3, 4], 5]]', function() {
    assert.deepStrictEqual(flattenArray([1, [2, [3, 4], 5]]), [1, 2, 3, 4, 5]);
  });

  it('should return [1, 2, 3, 4] for [1, [2, 3], 4]', function() {
    assert.deepStrictEqual(flattenArray([1, [2, 3], 4]), [1, 2, 3, 4]);
  });

  it('should return [] for [[], []]', function() {
    assert.deepStrictEqual(flattenArray([[], []]), []);
  });
});
