const findMin = require('../project/findMin');
const assert = require('assert');

describe('findMin', function() {
  it('should return 1 for [1, 2, 3, 4, 5]', function() {
    assert.strictEqual(findMin([1, 2, 3, 4, 5]), 1);
  });

  it('should return -4 for [-1, -2, -3, -4]', function() {
    assert.strictEqual(findMin([-1, -2, -3, -4]), -4);
  });

  it('should return 0 for [0, 0, 0]', function() {
    assert.strictEqual(findMin([0, 0, 0]), 0);
  });
});
