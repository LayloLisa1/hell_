const capitalize = require('../project/capitalize');
const assert = require('assert');

describe('capitalize', function() {
  it('should return "Hello World" for "hello world"', function() {
    assert.strictEqual(capitalize('hello world'), 'Hello World');
  });

  it('should return "A B C" for "a b c"', function() {
    assert.strictEqual(capitalize('a b c'), 'A B C');
  });

  it('should return an empty string for an empty string', function() {
    assert.strictEqual(capitalize(''), '');
  });
});
