const isAnagram = require('../project/isAnagram');
const assert = require('assert');

describe('isAnagram', function() {
  it('should return true for "listen" and "silent"', function() {
    assert.strictEqual(isAnagram('listen', 'silent'), true);
  });

  it('should return false for "hello" and "world"', function() {
    assert.strictEqual(isAnagram('hello', 'world'), false);
  });

  it('should return true for "evil" and "vile"', function() {
    assert.strictEqual(isAnagram('evil', 'vile'), true);
  });
});
