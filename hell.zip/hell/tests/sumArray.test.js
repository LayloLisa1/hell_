const sumArray = require('../project/sumArray');
const assert = require('assert');

describe('sumArray', function() {
  it('should return 15 for [1, 2, 3, 4, 5]', function() {
    assert.strictEqual(sumArray([1, 2, 3, 4, 5]), 15);
  });

  it('should return -6 for [-1, -2, -3]', function() {
    assert.strictEqual(sumArray([-1, -2, -3]), -6);
  });

  it('should return 0 for [0, 0, 0]', function() {
    assert.strictEqual(sumArray([0, 0, 0]), 0);
  });
});
