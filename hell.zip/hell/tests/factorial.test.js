const factorial = require('../project/factorial');
const assert = require('assert');

describe('factorial', function() {
  it('should return 120 for 5!', function() {
    assert.strictEqual(factorial(5), 120);
  });

  it('should return 1 for 0!', function() {
    assert.strictEqual(factorial(0), 1);
  });

  it('should return 6 for 3!', function() {
    assert.strictEqual(factorial(3), 6);
  });
});
