const fibonacci = require('../project/fibonacci');
const assert = require('assert');

describe('fibonacci', function() {
  it('should return 5 for fibonacci(5)', function() {
    assert.strictEqual(fibonacci(5), 5);
  });

  it('should return 0 for fibonacci(0)', function() {
    assert.strictEqual(fibonacci(0), 0);
  });

  it('should return 1 for fibonacci(1)', function() {
    assert.strictEqual(fibonacci(1), 1);
  });
});
