const chunkArray = require('../project/chunkArray');
const assert = require('assert');

describe('chunkArray', function() {
  it('should return [[1, 2], [3, 4], [5]] for [1, 2, 3, 4, 5] and size 2', function() {
    assert.deepStrictEqual(chunkArray([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]]);
  });

  it('should return [[1, 2, 3], [4, 5]] for [1, 2, 3, 4, 5] and size 3', function() {
    assert.deepStrictEqual(chunkArray([1, 2, 3, 4, 5], 3), [[1, 2, 3], [4, 5]]);
  });

  it('should return [[1]] for [1] and size 1', function() {
    assert.deepStrictEqual(chunkArray([1], 1), [[1]]);
  });
});
