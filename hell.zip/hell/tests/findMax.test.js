const findMax = require('../project/findMax');
const assert = require('assert');

describe('findMax', function() {
  it('should return 5 for [1, 2, 3, 4, 5]', function() {
    assert.strictEqual(findMax([1, 2, 3, 4, 5]), 5);
  });

  it('should return -1 for [-1, -2, -3, -4]', function() {
    assert.strictEqual(findMax([-1, -2, -3, -4]), -1);
  });

  it('should return 0 for [0, 0, 0]', function() {
    assert.strictEqual(findMax([0, 0, 0]), 0);
  });
});
