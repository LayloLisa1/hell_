const isPalindrome = require('../project/isPalindrome');
const assert = require('assert');

describe('isPalindrome', function() {
  it('should return true for "racecar"', function() {
    assert.strictEqual(isPalindrome('racecar'), true);
  });

  it('should return false for "hello"', function() {
    assert.strictEqual(isPalindrome('hello'), false);
  });

  it('should return true for "madam"', function() {
    assert.strictEqual(isPalindrome('madam'), true);
  });
});
