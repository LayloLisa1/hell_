const countVowels = require('../project/countVowels');
const assert = require('assert');

describe('countVowels', function() {
  it('should return 2 for "hello"', function() {
    assert.strictEqual(countVowels('hello'), 2);
  });

  it('should return 5 for "aeiou"', function() {
    assert.strictEqual(countVowels('aeiou'), 5);
  });

  it('should return 0 for "bcdfgh"', function() {
    assert.strictEqual(countVowels('bcdfgh'), 0);
  });
});
