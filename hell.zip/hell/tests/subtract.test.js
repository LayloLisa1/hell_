const subtract = require('../project/subtract');
const assert = require('assert');

describe('subtract', function() {
  it('should return 2 when subtracting 3 from 5', function() {
    assert.strictEqual(subtract(5, 3), 2);
  });

  it('should return 0 when subtracting 0 from 0', function() {
    assert.strictEqual(subtract(0, 0), 0);
  });

  it('should return 0 when subtracting -1 from -1', function() {
    assert.strictEqual(subtract(-1, -1), 0);
  });
});
