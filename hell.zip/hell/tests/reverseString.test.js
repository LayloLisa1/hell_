const reverseString = require('../project/reverseString');
const assert = require('assert');

describe('reverseString', function() {
  it('should return "olleh" for "hello"', function() {
    assert.strictEqual(reverseString('hello'), 'olleh');
  });

  it('should return "dlrow" for "world"', function() {
    assert.strictEqual(reverseString('world'), 'dlrow');
  });

  it('should return an empty string for an empty string', function() {
    assert.strictEqual(reverseString(''), '');
  });
});
