const arrayIntersection = require('../project/arrayIntersection');
const assert = require('assert');

describe('arrayIntersection', function() {
  it('should return [2, 3] for [1, 2, 3] and [2, 3, 4]', function() {
    assert.deepStrictEqual(arrayIntersection([1, 2, 3], [2, 3, 4]), [2, 3]);
  });

  it('should return [] for [1, 2, 3] and [4, 5, 6]', function() {
    assert.deepStrictEqual(arrayIntersection([1, 2, 3], [4, 5, 6]), []);
  });

  it('should return [1] for [1, 1, 1] and [1, 1, 1]', function() {
    assert.deepStrictEqual(arrayIntersection([1, 1, 1], [1, 1, 1]), [1, 1, 1]);
  });
});
