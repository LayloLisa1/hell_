const divide = require('../project/divide');
const assert = require('assert');

describe('divide', function() {
  it('should return 2 when dividing 6 by 3', function() {
    assert.strictEqual(divide(6, 3), 2);
  });

  it('should throw an error when dividing by 0', function() {
    assert.throws(() => divide(1, 0), /Cannot divide by zero/);
  });

  it('should return -2 when dividing -4 by 2', function() {
    assert.strictEqual(divide(-4, 2), -2);
  });
});
