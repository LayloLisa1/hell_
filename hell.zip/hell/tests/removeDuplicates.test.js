const removeDuplicates = require('../project/removeDuplicates');
const assert = require('assert');

describe('removeDuplicates', function() {
  it('should return [1, 2, 3, 4, 5] for [1, 2, 2, 3, 4, 4, 5]', function() {
    assert.deepStrictEqual(removeDuplicates([1, 2, 2, 3, 4, 4, 5]), [1, 2, 3, 4, 5]);
  });

  it('should return [1] for [1, 1, 1, 1]', function() {
    assert.deepStrictEqual(removeDuplicates([1, 1, 1, 1]), [1]);
  });

  it('should return [0] for [0, 0, 0]', function() {
    assert.deepStrictEqual(removeDuplicates([0, 0, 0]), [0]);
  });
});
