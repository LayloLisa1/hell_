const removeNullAndUndefined = require('../project/removeNullAndUndefined');
const assert = require('assert');

describe('removeNullAndUndefined', function() {
  it('should return [1, 2, 3] for [1, null, 2, undefined, 3]', function() {
    assert.deepStrictEqual(removeNullAndUndefined([1, null, 2, undefined, 3]), [1, 2, 3]);
  });

  it('should return [] for [null, undefined]', function() {
    assert.deepStrictEqual(removeNullAndUndefined([null, undefined]), []);
  });

  it('should return [0, false, ""] for [0, false, "", null, undefined]', function() {
    assert.deepStrictEqual(removeNullAndUndefined([0, false, "", null, undefined]), [0, false, ""]);
  });
});
