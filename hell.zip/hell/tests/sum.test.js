const sum = require('../project/sum');
const assert = require('assert');

describe('sum', function() {
  it('should return 5 for 2 + 3', function() {
    assert.strictEqual(sum(2, 3), 5);
  });

  it('should return 0 for -1 + 1', function() {
    assert.strictEqual(sum(-1, 1), 0);
  });

  it('should return -5 for -2 + -3', function() {
    assert.strictEqual(sum(-2, -3), -5);
  });
});
